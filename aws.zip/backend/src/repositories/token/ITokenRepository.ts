export interface ITokenRepository {

}
