export interface ICommonFields {
    id: number;
    createdAt: string;
    deletedAt?: string;
}
