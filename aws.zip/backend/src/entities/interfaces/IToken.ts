export interface IToken {
    refreshToken: string;
    userId: number;
}
