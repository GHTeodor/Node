export interface IComment {
    postId: number;
    title: string;
    body: string;
}
